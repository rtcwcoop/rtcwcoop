=====================================
ACTIVE CONTACT: ssf.sage @ gmail.com
=====================================
Map support RTCW Coop 0.9.9.

//Best viewed on notepad!
//
//===================================================================================================>>>
// Mission name : Capuzzo
// BSP names : 
// 1.	City 
// 2.	Airport 
// 3.	Road
//
//(Hopefully more to come)
//
// Release date: January 2013
// Version: Second Beta
//
// THE COOP VERSION IS BASED ON THE RTCW SP CONVERSION!
//
//RTCW SP:
// Previous version release thread: 
//	http://forums.warchest.com/showthread.php/31673-Release-SP-Capuzzo-3-maps
//
// Author: -SSF-Sage
//
//
//W-ET:
// The first two maps are originally based on a Wolfenstein Enemy Territory MP map called Capuzzo Airport.
// Authors of the original map: {SSF}Sage and Pegazus from S&M mapping
// Link to the original map: http://www.splashdamage.com/forums/showthread.php?t=18293
//
//
// Contact Sage: -SSF-Sage @ splashdamage.com/forums or ssf.sage @ gmail.com
// SM-Mapping site:  http://www.hot.ee/smmapping/
//===================================================================================================>>>

Please contact me for any feedback, suggestions, constructive critisism, bug report etc.

===============================
Installation:

	1) Unzip coop_capuzzo_...ZIP into the coopmain folder on game installation folder.

	*After this you should find a pk3 inside the following folder:  		

	X:\whatever\My-rtcw-installation\coopmain\


===============================
Note!

	If you have any older version of Capuzzo, delete it!

===============================
Playing the mission:

	From "create server" menu, by selecting first map (city)

	Or by command /coopmap city

===============================
KNOWN BUGS in current version:

	-Some dark spots in the terrain
	-Some overbright textures

===============================
Story:

	January 1943 - The war in Africa is finally coming to an end. The Allied intelligence has discovered 
	a group of Axis engineers planning a new super plane in Capuzzo Airport. You have been sent to steal
	the blueprints and sabotage their project. Once you are done with it, you will be transported to a
	friendly location.

===============================
Uninstallation:

	1) Remove the pk3 from your coopmain folder

===============================
Credits:

	ID, Nerve, Graymatter and activision    For the great game

	Splashdamage				For some of the assets. It was not possible to keep the feeling of the maps without using those. Most of them were edited but not all of them are.

	Pegazus					For working with me on the original W-ET map, and for additional help



	Bradburger			 	Base for the seafire sounds

	JillianCallahan		 		Base for the seafire stopping sounds


	
	Jesters-Ink & Buglord		 	Base for the Fw-190 texture

	Jester, Robo, Kristorf and FBS  	Base for the Seafire texture

	Emel 					Base for the Bf-109 texture

	Dr.EViL					I used small details from his skins to make my own African player skins


	Anyone that has been with us/me in either making the original W-ET map or during the RTCW SP project.



			THANK YOU ALL!

===============================

Thanks for testing (COOP)

	Angsthase

	N3rwitZ

	{WeB}*GANG$TA*


Thanks for testing and feedback (SP):

	Pegazus

	My and Pegazus' real life friends

	Shagileo

	Ronboy

	Eugeny

	Vicpas

	Shurr

	Dave1988

	tzs

	If I forgot to add your name, let me know. :)

	And ofcourse the tons of W-ET testers, most specially |>B<| Bunker clan and Owen from it.

===============================